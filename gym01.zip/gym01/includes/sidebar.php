<?php
// $pages = array(
//     'dashboard.php',
//     'members_list.php',
//     'add_type.php',
//     'view_type.php'
//     // Add other page names here
// );

$current_page = basename($_SERVER['PHP_SELF']);

$countQuery = "SELECT COUNT(*) as total_types FROM membership_types";
$countResult = $conn->query($countQuery);

if ($countResult && $countResult->num_rows > 0) {
    $totalCount = $countResult->fetch_assoc()['total_types'];
} else {
    $totalCount = 0;
}
?>
 
 
 <!-- Main Sidebar Container -->
 <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="" class="brand-link">
    <img src="<?php echo getLogoUrl(); ?>" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light"><?php echo getSystemName(); ?></span>
</a>

<?php
function getSystemName()
{
    global $conn;

    $systemNameQuery = "SELECT system_name FROM settings";
    $systemNameResult = $conn->query($systemNameQuery);

    if ($systemNameResult->num_rows > 0) {
        $systemNameRow = $systemNameResult->fetch_assoc();
        return $systemNameRow['system_name'];
    } else {
        return 'CodeAstro';
    }
}

function getLogoUrl()
{
    global $conn;

    $logoQuery = "SELECT logo FROM settings";
    $logoResult = $conn->query($logoQuery);

    if ($logoResult->num_rows > 0) {
        $logoRow = $logoResult->fetch_assoc();
        return $logoRow['logo'];
    } else {
        return 'dist/img/AdminLTELogo.png';
    }
}
?>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMQEhUSEhIWExUXFxcYGBgXGBcVFxoVGhYXGBoYFRoZHyghGB0mHBcYITEhJTUrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGzUlICQwLTc2KysrKzgyLTIuNzIwNi0tNi01Ny0tNy8tLS02LTIvLS0tLys4Ky0vKy0rLSstLf/AABEIAO8A0gMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABgcEBQgDAgH/xABLEAABAwIDBQUCCgYIBAcAAAABAAIDBBEFEiEGBzFBURMiYXGBMpEIFCNCYnKSobGzM1JUc4LRFRYkNUNTdKKjssHDNGOD0+Hw8f/EABkBAQADAQEAAAAAAAAAAAAAAAADBAUCAf/EACoRAQACAgEDAgQHAQAAAAAAAAABAgMRBBIhMRNRIkFh8BQzcYGhsdEF/9oADAMBAAIRAxEAPwC8UREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERARFqNrNoI8OpZKqQEhg7rRxe8mzWDzJGvIXPJBt1GdpNvsPw+4nqW5x/hs+Ukv0LW3y/xWCpvF9oq+v1qqt0LDr2EB7NoB+a4t7zx5lQnaURwtbFE3KHauPMgcL8+P4ILfp9/lM6cMdSSsgJt2pe0vHiYgOHk4nwKtylqGSsbJG4PY9oc1zTcOaRcEHmCFxCuifg8bQGekkpHm7qdwLL/5UlyB6ODvRwQW0iIgIiICIiAqw203y01BUGnihNU9hyykPEbGu5tByuzOHMaAcL3upbvBx7+j8PqKkHvtZlj/AHjyGMPjYm/kCuQHuJJJNydSTqSepQdTbN72sMrLNM3xaQ/MnGQej9WfeD4KcseHAEEEHUEagjwXGWz0oEoY8BzH6EGxF+I4+71U5wqeejN6Gskp+fZk5ojc31jfdp80HSyKFbtNs3YiySKdrWVUBAkDbhr2O9mRl+tiCOR8wFNUBERAREQEREBERAREQFUW+yt7WooqO/dbnqXjy7kZ95kVh7YbRx4ZSvqZQXWs1rBo58jjZrR+N+QBKoCv2okxGulqpYmxlsccbWNcXBrbudq48TqeiDObE1vABV3tLNnnd4AD7r/iSpu+qcfBV7iT7yyH6bvxKDGVk7gcR7LFWx30mikjtyuAJB+Wfeq6ihc72Wk26C62eA1U9HO2oiY7OwOymx0LmObf0zX9EF/7S7c1Er5WULmQQQv7J9U9hmc+ckN7Omj4Ps4htzxJ08cKbbKvwoCWtlbXU7rhxETIZo5C0llxGcjmlwynpf3x/d/jMc0fxQRGMUwjc0njIe9mkI5HPd3P2h0WVvJfmw+cH/yz/wAVizJ5OWM8VntG/H0XowUnFNvo+cObVYhOTU1NSXhjJJTHM6CGEyDOyGCNntODSLuJ00431867aWugfLhrqyXsYWduakWdVmnytAga4i2cyOAD+Oo8lLKOJsLXZeLyHHzEbGD/AGsb7lD8PhbPjNVm1DYIP9skEo+9gUWPlXm1rb7a/wASX49YrWNd9s2erqsJhjrxUVJDXx9tTTzmpa6Jzg0i7gMkouNW6AjmOPvTb0K+abIw4e119Kd7p+08Y+2sIzIOFh7l6bwXZqVrf1p6cf8AFao5h8sQw+ljqmA05fURVD7d6Ko7W8chcNWahwv9MX0UmHk5Jxbnzv7/AF++7jLhpF9R7PXfDtwyvoIImtdDL27u3hce9G+NlrG3tNPaXDuBt1FhTin+2Gx1Y/LUROFbHlAEsYvI5gvlMjR7Ztpmbe4AKgjoXC5LTobHTgeh6LQxZK3ruJU70ms6mH5DJlcHDkQfcbq0aaz2AkXVVqwMKqXdjHr8xvvsFI4SPY+q+J4tSSDRs2amf4h4uwfbDV0AuXMYxB0bGTNAzwyRyt6ZmvBF1d27rb5uK9pG+LsJ4gC5gdna5h0zsNgbX0IPC41N0E1REQEREBERAREQEREFSfCBqO5Qw8nSySW8Y47D/nKqjBh3pj9Ifc0K1vhA0/doZeTZZGer4wR/yFVTgx70w+mPvaEG0Cr+pN3u+sfxVgBV/Ujvu+sfxQbjBrNjueZP3WCzu0HVazDjeLycR77Fe6CR7F1TWVtiRaWF7LdSHB1vcCvfauN0FNVx9q98LjB2Ye4uLZDJmfG1x1IDWNNuV/NRRwvY3IINwQbEEcCDyK/a6WScfKzSSWHdzuJAPUDr4qC2HeTq/T+E1cuqdK1No8fkpg2Tse0hsM7mus9njlIs4cOYWr2aqL4rWubY3hiLdbA9yK2ttFrf63U8tL2UznskdHke0MLidMruzPDUXsSdL87LQ4Tjr4Kp1V2dxIC10YOoj7uUNPMtytVSnHnotGu/9rFs0dUTvslu120IkpnBzHRSQ1EGdjrEjUvDmkaOaQ02PgvSlxR1BLLM9majnkLpLAODS49ydgHtNcC0OHG4v0vEtpMcFYe7GWMzB7i+2ZxaCGNsNA1uZx1vcuK/dksCdVysJzfFo3ZjcnK5wN8jAdOPE9Lrv0K1xfF2j2+/4c+rNr/D3ldgqFUm8+Nvx12UAZ6UOdYcXB72gnqbAD0Vk9qqv3gVAfUl4NwaRtj4F77fiqnAprLv6J+XbeNAVOMGPyEf1VB1OMGHyEf1VtMwxgXgk+qpDugqcmLwAf4sMzD5BokH3sUfxg2gk+qt/uhps+L05/y4ZnnyLBH+LkHRaIiAiIgIiICIiAiIg0O22zLMUpH0z3ZCSHseAHFkjfZcAePMEaaOOo4rnvFcBmwurmgncyRxZHIHMuAWEuaDYjQ6aj711Eqb364dlnpKkWAe2SneSQNf0kf350FfsqmnnbzUJxJtpZB9N34lSfha44uaNb8De9vctFj8JEpdycGnTW1xbW3DUFBgw1DmXyuIutpgDZKqojh7Utzki9gbWBPD0WpfGRxBC3OyofDUMqCw5ISHSE6BrXOEdyfN40XNt9M68va63G03/qCf2x/2G/zX7/UE/tcn2G/zU0MwEefu3yg2vzXrB3mg6XIBNupCyJ5WWPm0owY/ZBf6gn9rk+w3+aDYE/tb/sN/mp20A6AgnoCCfcsTE8SgpheaVkfQE94+TeJ9EjlZpnUT/BODHEbmEcpNh6dpzSGSc9Hu7t/qtt991JI4g0BrQGgCwAFgB0AHBRDEt4sTbiCF8ltMzyImel7k+Wi1UOI4liQcQRBCNC5vcB1Ggdq55txANutrqScWa/fJOo+riMmOvanf9Ekx7Gi54o6Y5qh+jiNRCz5z3HqBwH/wDX23NW11U6OM9yJjIRbnkHD0JI9FvqupbQ0r/wCj43PBc2OWrtcdo4OIjiPPRp1Gg04kgqAvjcNSCrfHxdPf7n6/4r5snV2fCnFDIGRRgnXI3T0ChkEBeQBzIFzoLnxKls+hdbkNOY0sPVWld91rTUNEMY70j44235ue8AcFee7Xd/8A0WZJppWzVErWtJa2zGMGuRl9Td2pJtfK3QW1qjYChE+JUjXWDYz8ZeTYACNncPrIQukQb6hB+oiICIiAiIgIiICIiAoXtps6KyOeKVjiHgGORozdm9urXW52PEaXF+qmi1stNUZjlmABPAt4DoOKDm7FsBqaZo+MU7mx5wO1j+UiPG5JGrL34FaHE42ubHIwtNnZCW/qu6jlz966rOD2YxodwfmJI4rR7Ubt6GuIcYWxPvd0kQEbz4mws4/WBQcrz8D9f/orn3S7KxzYbXSTtuKgljfBjcwzN8cxP2Ass7hm9rf44XQ3BLDGA825ZwbA+ICtPCcFZTwmEWDCA0BoyhrQLANQVDgTB2MsErf7RSkRvNzdzSAY5RrwczX0K2td2dPSulJDBkYXOJPO343tYdVlbVYUabEqV1y5lXFLTuIFrGIdrGT46uA8lUu8DaPtpTStkL4YnZdBYOcLgu462Og5aHqsu/Gm2fpjx5+/3X654jFufPh77RbZvf3KSN8IHCSx7Rx68bMHHhrw1HBRGreS9znHMQAbuJcSSRqSePHmvITAa3v/AAgX8HH/APV8ukFjxuQ0cNNLc7+C0aY60jVYUr3m07lvdlsHNbUAFpdG0B0mXUtaLXAHIuPPxJVmYfhAxONzYG9jh0JDXObcOnfcAxxa6RgHV3PgOdorsRRSS07IIH9m+uqOwvYZhBFGHyuBtrZrnD+JdDYZgEdPTfFmaMAAFtLWta3uv46qOK9d+qfEeP8AXc26a6j5+Ua2y2SZNhD6WlhDSWMcxrB85nfAF+Fzpf6RXMLrHM2waAb8ydDYcT4rs7DqZ8YLXPzjTLpawVZbW7l2VtS+eGoFOJHFz2dlnBJN7ts5tr8SOZ1U6JR+E0w7Ql1ssQHHRtyOOvjqt7QUUlQHNpoZajqWA9m06cZHWa0H+SuLC9ztHTkPuah/PtwHMv4RgZftZvNTWnwfJC6LNbNbQCzG2PBrRYD7kEE3WbJ/Fi6Sqt272tswataxos1oPzuFzbQ6cbXNoLXz4ZmYwB2V7A0B4HQdFnMvYX1PPkg+kREBERAREQEREBERAUW2825p8IiDpe/K4Hs4WkZneJPzW9Xe4E6Lf4pXspoZJ5DZkTHPcfotBJt1Oi4/2hxmfFKt88l3SSvAYwa5QTZkbPAaDx48SgkW0m9nEqwkNmNNGeDIO5YeL/bJt4geAUPqcSmlN5JpJD9J7nH7yre2Z3dU8EYdUNE0xFzfVjT0a3g7zPpZSF2HFg7gFujRb7gqFv8AoY4nVe63Xh21uXPbJ5Gm4c5p6gkH3qQYTt/iVKCIq2axBFnu7UD6okvlPiFbq1OM7OU1W09pE1r+UkYDHg9TbR/r7wva82N94J4s/KVQVuM1E7s8tRLI69wXvc4gnpc6LBV27vRHFHJQva0TQvJdoPlGPN2SDroQPCw6rM2s2QjrInBoDZQLsceTuhPHKeGt+qTzq1ydNo19SOLM06on9lDIvaWme15jLSHhxaW21zA2y2630V3bB4BDRwtzBpqHavcQLgn5jSeQ4acTcqfkZ4xV3raLDhnJbSk6Sulhc18Uj43MJLXMcWlpIsS0g6XHRZE+OVUji59TM5x4l0jyfeSrc3rYlFFRmJzQ6SUgMGl25SCX+FuH8Xmt7shSsjoqYMaG3hicbAaucxrnE9SSSq087WOLzXzPumji7vNepQYxeoGonlH/AKj/AOanuwe92qoXZKpz6uCx0cbytOtix7tSL2BDr6cLc7VexpBBAIPEEAgjxCoTeBg4pK2RjG5Y3ASMA4BruIHgHBw8gFJxuZGa3TrTjNxpxxve2RtTvEr8QkLnzvijucsUTixjR0OXV58XX9OCj/8ASs/+fL9t381YG57BGvMtVIwOykMjuL2da73AHmAWgHxKtTTouM/PjFfpiN/u6xcSb16t6c8YVtXW0rw+GrmYR9MuafrNddrvIgrpbdbtwMXpi5wDJ4iGytHDUXa9vMNdY6HgWnzNYb5KVhpY5coziYNDra5Sx5Iv0u0H0Xn8G6YiuqGX7ppi4jxbLGAfc53vVnBm9WnVrSHLj9O3S6HREUyIREQEREBERAREQV/v0rTFhEoBsZHxx+heHEeoYQqM3VUYkr2uOvZsfIPPRg9xff0Vz/CEgLsKBHzKiJx8rPZ+Lgqg3QvtWvHWB4H24z+AKh5Ez6VteyXD+ZC5Q5UXtJtlVzTyZKiSOMPcGNjcYwGgkC+Wxcbam/Mq7w5c318RZLI08WvcD5hxCzv+dSszaZhc5lpiI03eH12KPtLE6rmF+PysrNORvcFWNS48XMaX0lWx9u834vI4A88pA1HnZbLY6vidRU+R7e7ExrhcAh4aA4Ecje/vut7mXOfkRNtTTw6xYdRuLeVI4vtHI3EPjDY3RlmVvZvBY4sA1Dxyve/hp0VsYZi3axtkjdmY4Ai/4eBHC3gq83wgfGYSLXMWvXR7rX+9eG7TGyyX4o492Qks8JLcPJwHvA6lWMmOMuGLxHiENLzjyzWZT44DTyVra1ws8NsWEd0ycBJfqG3GvgeS22IMjjY6VzsjWtLnHiLAXKxnMI4iyrveVtASfibCcos6Xjq7Qtb5C4PnboquPHbLeI34/pYveuOszpFNosYdWTulde3BgPzWDgP+p8SVeOzNUPilMDp8hCPD9G1c9LoHAIWupKa2nyEPD921WufWsUrCvxJmbTLdh6r7fDhueCOoA1jdld9R/AnycAP41v6qvdBUww30lZKR4uZkNrfVLvcs6ocyZhjlbdptcctCCPvAVDFE4r1vC3k1krNXnsfhvxWjhiIs4NzP+u7vO917ei3GZeLZAdbrX7P4n8ahEw4OfLl+o2V7W/7QFFaJtM3n3/tJXVdVhHN8J/sTP37Py5VifBw/vGf/AErvzoVkb3j/AGJn79n5cqx/g4f3jP8A6V350K2OB+SzOX+Y6LREV1WEREBERAREQEREEe3g4Ia/DqmmaLvcy7B1kYQ9g9XNA9Vyhs7iho6mOax7ju83mWnuuHnYn1su0FQu+PdhIJX19FGXsec00TRdzH85GAe008SBqCSeB7vkxExqXsTqdwktJVslY2SNwcxwu0jgQtLimx9HUyGWSLvu9otc5tz1IBtfxVRYHtHUUZ+Rks06lju8w+h4HxFipPDvRmA71PGT1Bc37jdZc8PLS28cr8cnHePjhMKTYahjcHiEuINxme5wv4gmx9VJHyAAkkADUk6ADqVVr96MttKeMHxc4/yUdxza6qrBlkflZ+owZWnz5u8iSn4TNkn45PxGKkfDD624xkVlW+RmrGgRsPVrb6+ri4+RC89h/wDx9P8AvB+BUq3a7rpsTPbTh0NNlOVxFnSOIOXswfmg2JdwNrDnaF1VPPh1UWPBjngk9zmm4IvxadCDwII5FaPpxFOiPZS6936pdAHXiqP3gttiE9urPy2LdDehUW/QRXtx79r+V1FXmfEKnRplnmeAGtHFx0AA5AD3AKpxOPfHaZsscjNW9YiGtV67PuIpqext8jF+W1VvvF2KkwidjHXdG+NhZJyLw1olHgQ+5t0c1MK29ngibEY2PDAGtJzA5RoAbGxsNFNycVskRpHgyRSZ2kG8fEnQz0UzfajdI7pexjuD5jT1U+ifHM0PabhwDgR0IuCqL2ix+Ste10ga0NBDWtvYX4nXUk6e4LZYJtxPSxiLK2RrdG5rhwHS4OoUGTiWnHWI8wmpyIi8zPiVhbb1ppaSRwdZzx2bdbG77g28m5j6L43dVGWghFtPlPzXqs9pNqJq8t7SzWNvlY29rnmb8T/95lZez22k1HF2IYyRgJLc1wW3NyAQdRfXXqk8W3o9Pz28/EV9Tfy0mm9iQOomWP8Ajs/LkXx8HD+8Z/8ASu/OhUG2k2qlrg1j2tYxpzZW31da1yT0BPvVt/B02cfGyaukaWiUCOK/FzQbvcPDMGgfVKs8bFOOnTKDNeL33C6URFOiEREBERAREQEREBERBE9ot3OG17i+amaJDxkjJieT1dl0cfFwKicm4WgJ0qKoDpmiP/bVsIgqZu4Sg51NUfWIf9tSTAt1eF0hD20/avHB0xMvrlPcv42U1RB+AWUd2s2HosUANTDd4FmyMOSQDXTMOI1OjrjVSNEFTncJh/7RVfai/wDbUx2S2BocL71PF8oRYyvOeS3QHg0fVAupOiDAxvBoK2J0FTE2WN3J3I9WkatPiLFV3U7iMOc4lstTGD80PjIHkXMJ95Vpogr7AtzuGUpzOjfUnX9O4OAvp7LQ1p9QVg1+4zDZHZmPqIR+qx7XNHl2jXO+9WeiCvcD3N4ZTOzOY+pI4du4OaOXstDWn1usPENxuGyvLmOqIQfmse0t9O0a4/erORBW2Ebk8MgeHvE1RYghsrxkuOoY1ubyNwrGijaxoa0BrQAAAAAANAABwC+0QEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERARacQ1ul5YuNjofZ/WGntak24d0dTb8MFYWFpfEHEnVtx3Sw/R0Ic7j0YOBJsG5RaaWnrCSO1YACcpBAcRY2zXjIBvbh1PkvvsKuxvKy9xwFtO9m4g6ju28iD1QbZFpX09YRYSRjhbj7QcD3rNF25RYgWub8jYetRHVm+R0beFrm+lhx7mp9r3t6HMG1RYDIJix7XyAk5g0jR1iwAagWaQ65vY8limhqSRaUM/RX7z3g5TdwF7ZL8DxvbW19A3KLSOoqjk4fO0M0lrEaNJDb6HW/G2mnFHYfUZhaUhoMd++4uOU2c72bat+ba19UG7RY2HQvZG1sjsztbm5PEk2BdqQAbXPGyyUBERAREQEREBERB//2Q==" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">ELITE GYM</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link <?php echo ($current_page == 'add_type.php' || $current_page == 'view_type.php' || $current_page == 'edit_type.php') ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-th-list"></i>
              <p>
                Membership Types
                <i class="fas fa-angle-left right"></i>
                <!-- <span class="badge badge-info right"><?php echo $totalCount; ?></span> -->
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="add_type.php" class="nav-link">
                  <i class="fas fa-circle-notch nav-icon"></i>
                  <p>Add New</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="view_type.php" class="nav-link">
                  <i class="fas fa-circle-notch nav-icon"></i>
                  <p>View and Manage</p>
                </a>
              </li>
            </ul>
          </li>
        
          <li class="nav-item">
            <a href="add_members.php" class="nav-link <?php echo ($current_page == 'add_members.php') ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-users"></i>
              <p>Add Members</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="manage_members.php" class="nav-link <?php echo ($current_page == 'manage_members.php' || $current_page == 'edit_member.php' || $current_page == 'memberProfile.php') ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-users-cog"></i>
              <p>Manage Members</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="list_renewal.php" class="nav-link <?php echo ($current_page == 'list_renewal.php' || $current_page == 'renew.php') ? 'active' : ''; ?>">
            <i class="nav-icon fas fa-undo"></i>
              <p>Renewal</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="report.php" class="nav-link <?php echo ($current_page == 'report.php') ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-file-invoice"></i>
              <p>Membership Report</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="revenue_report.php" class="nav-link <?php echo ($current_page == 'revenue_report.php') ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-money-check"></i>
              <p>Revenue Report</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="settings.php" class="nav-link <?php echo ($current_page == 'settings.php') ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-cogs"></i>
              <p>Settings</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="logout.php" class="nav-link <?php echo ($current_page == 'logout.php') ? 'active' : ''; ?>">
              <i class="nav-icon fas fa-power-off"></i>
              <p>Logout</p>
            </a>
          </li>

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>